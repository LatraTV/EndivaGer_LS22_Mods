--[[
	ReduceMaintenanceCosts.lua
	
	Author: 	Ifko[nator]
	Date:		24.11.2021
	Version:	3.0 
	
	History:	v1.0 @24.11.2021 - initial implementation in FS 22
]]


ReduceMaintenanceCosts = {};

function ReduceMaintenanceCosts.prerequisitesPresent(specializations)
	return SpecializationUtil.hasSpecialization(Wearable, specializations);
end;

function ReduceMaintenanceCosts.registerOverwrittenFunctions(vehicleType)
	SpecializationUtil.registerOverwrittenFunction(vehicleType, "getRepairPrice", ReduceMaintenanceCosts.getRepairPrice);
	SpecializationUtil.registerOverwrittenFunction(vehicleType, "getRepaintPrice", ReduceMaintenanceCosts.getRepaintPrice);
end

function ReduceMaintenanceCosts:getRepairPrice(superFunc)
	return superFunc(self) / 2;
end;

function ReduceMaintenanceCosts:getRepaintPrice(superFunc)
	return superFunc(self) / 2;
end;