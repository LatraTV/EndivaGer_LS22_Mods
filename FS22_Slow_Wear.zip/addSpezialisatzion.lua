-- Register functionality by: Ian898 
-- Date: 26/11/2018
-- THANK YOU IAN!

-- "by" modelleicher
-- used to remove locked steering axle when front loaders are attached


local modDirectory = g_currentModDirectory or ""
---@type string name of the mod.
local modName = g_currentModName or "unknown"

---Add mod specs to game specs.
local function initSpecialization(manager)
    if manager.typeName == "vehicle" then
        g_specializationManager:addSpecialization("slowWear", "slowWear", modDirectory .. "slowWear.lua", nil)

        for typeName, typeEntry in pairs(g_vehicleTypeManager:getTypes()) do
            if SpecializationUtil.hasSpecialization(Wearable, typeEntry.specializations) then
                g_vehicleTypeManager:addSpecialization(typeName, modName .. ".slowWear")
            end
        end
    end
end

---Init the mod.
local function init()
    TypeManager.validateTypes = Utils.prependedFunction(TypeManager.validateTypes, initSpecialization)
end

init()

---Helper method for getting the scoped spec table.
function Vehicle:cfcMod_getSpec()
    return self["spec_" .. modName .. ".slowWear"]
end
