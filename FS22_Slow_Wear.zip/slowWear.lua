--
-- slowWear
--
--
-- @author monteur1
-- @date 25/11/2021
--

slowWear = {};
slowWear.g_currentModDirectory = g_currentModDirectory

function slowWear.prerequisitesPresent(specializations)
    return true
end

function slowWear.registerEventListeners(vehicleType)
    EL = vehicleType.eventListeners
    table.insert(EL.onPostLoad, slowWear)	
end

function slowWear:onPostLoad(savegame)
	local spec = self.spec_wearable

    spec.wearDuration = self.xmlFile:getValue("vehicle.wearable#wearDuration", 600) * 60 * 1000 * 2 -- default 600min / 10h
	
	local currentValue   = spec.wearDuration
	
    if spec.wearDuration ~= 0 then
        spec.wearDuration = 1 / spec.wearDuration
    end
	
	currentValue         = spec.workMultiplier  / 2
	spec.workMultiplier  = currentValue

	currentValue         = spec.fieldMultiplier / 2	
	spec.fieldMultiplier = currentValue
	
	print("SlowWear overwrite Values")
end
