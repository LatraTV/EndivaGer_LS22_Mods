-- Author:svenp (sven.pegels@gmail.com)
-- Name:Implement Wear Info Hud
-- Description: Script mod for displaying the condition (maintenance bar) and damage of the current vehicle and its implements
-- Icon:
-- Hide: no
-- Credits to Fruchtzwerg's Inspector mod (https://www.farming-simulator.com/mod.php?mod_id=126897&title=fs2019) for inspiring this mod's idea and showing how to get the necessary vehicle data

--[[  Note:
	- 'condition' is defined a the short-term wear of the vehicle, which is also displayed in the maintenance bar at the top left of the spedometer, and can be fully repaired at the shop
	- 'damage' is defined as the 'long-term' wear of the vehicle, which is not displayed anywhere, and can not always be fully repaired and impacts the vehicle's performance
	- 'paint condition' is defined as the wear of the paint on the vehicle, which only has a visual effect, and can be fully repainted at the sore
]]

--TODO: Change the refresh rate of the hud to once every ... seconds instead of every frame


ImplementWear = {
	VERSION = 8,
	settingsFileName = "ImplementWearSettings.xml",
	color = {
		normal = {1.0, 1.0, 1.0, 1.0},
		warning = {1.0, 1.0, 0.0, 1.0},
		urgent = {1.0, 0.0, 0.0, 1.0}
	},
	position = {0.57, 0.074},
	includeBrand = true,
	maxNameLength = 20,
	childIndent = 3,
	font = {
		size = 0.011,
		line = 1.2
	},
	limits = {
		warning = 100,
		urgent = 50
	},
	defaultDisplayMode = 1,
	currentDisplayMode = nil, -- Is set to defaultDisplayMode in loadMap(), late replaced when loading the saved settings
	nDisplayModes = 6,
	displayModes = {
		DISPLAY_OFF = 0,
		DISPLAY_NORMAL = 1,
		DISPLAY_DAMAGE = 2,
		DISPLAY_FULL_NAME = 3,
		DISPLAY_PAINT = 4,
		DISPLAY_PAINT_FULL_NAME = 5,
	}
};

function ImplementWear:loadMap(name)
	print("Info - ImplementWear: Loading mod")
	ImplementWear.currentDisplayMode = ImplementWear.defaultDisplayMode;
	ImplementWear.loadSettings();
end

function ImplementWear:deleteMap(savegame)
	print("Info - ImplementWear: Exiting")
	ImplementWear.saveSettings();
end

--[[
	Loads the saved settings from the settings file, if such a file is present and the version numbers match.
	Otherwise saves the current settings to a new settings file (existing settings will be overwritten and lost).
]]
function ImplementWear.loadSettings()
	print("Info - ImplementWear: Loading settings...");
	local settingsFilePath = ImplementWear.getSettingsFilePath();
    if settingsFilePath == nil then
		print("Error - ImplementWear: Could not get a valid file path")
		return;
	end

	if fileExists(settingsFilePath) then
		local file = loadXMLFile("ImplementWearSettingsFile", ImplementWear.getSettingsFilePath(), "ImplementWear");
		local xmlVersion = Utils.getNoNil(getXMLInt(file, "ImplementWear#VERSION"), 0);
		if xmlVersion == ImplementWear.VERSION then
			ImplementWear.color.normal[1] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.normal#R"), ImplementWear.color.normal[1]);
			ImplementWear.color.normal[2] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.normal#G"), ImplementWear.color.normal[2]);
			ImplementWear.color.normal[3] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.normal#B"), ImplementWear.color.normal[3]);
			ImplementWear.color.normal[4] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.normal#A"), ImplementWear.color.normal[4]);
			ImplementWear.color.warning[1] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.warning#R"), ImplementWear.color.warning[1]);
			ImplementWear.color.warning[2] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.warning#G"), ImplementWear.color.warning[2]);
			ImplementWear.color.warning[3] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.warning#B"), ImplementWear.color.warning[3]);
			ImplementWear.color.warning[4] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.warning#A"), ImplementWear.color.warning[4]);
			ImplementWear.color.urgent[1] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.urgent#R"), ImplementWear.color.urgent[1]);
			ImplementWear.color.urgent[2] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.urgent#G"), ImplementWear.color.urgent[2]);
			ImplementWear.color.urgent[3] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.urgent#B"), ImplementWear.color.urgent[3]);
			ImplementWear.color.urgent[4] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.color.urgent#A"), ImplementWear.color.urgent[4]);
			
			ImplementWear.position[1] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.position#x"), ImplementWear.position[1]);
			ImplementWear.position[2] = Utils.getNoNil(getXMLFloat(file, "ImplementWear.position#y"), ImplementWear.position[2]);
			ImplementWear.includeBrand = Utils.getNoNil(getXMLBool(file, "ImplementWear.name#includeBrand"), ImplementWear.includeBrand);
			ImplementWear.maxNameLength = Utils.getNoNil(getXMLInt(file, "ImplementWear.name#maxNameLength"), ImplementWear.maxNameLength);
			ImplementWear.childIndent = Utils.getNoNil(getXMLInt(file, "ImplementWear.name#childIndent"), ImplementWear.childIndent);
			ImplementWear.font.size = Utils.getNoNil(getXMLFloat(file, "ImplementWear.font#size"), ImplementWear.font.size);
			ImplementWear.font.line = Utils.getNoNil(getXMLFloat(file, "ImplementWear.font#line"), ImplementWear.font.line);

			ImplementWear.limits.warning = Utils.getNoNil(getXMLInt(file, "ImplementWear.limits#warning"), ImplementWear.limits.warning);
			ImplementWear.limits.urgent = Utils.getNoNil(getXMLInt(file, "ImplementWear.limits#urgent"), ImplementWear.limits.urgent);
			ImplementWear.currentDisplayMode = Utils.getNoNil(getXMLInt(file, "ImplementWear.displayMode#currentDisplayMode"), ImplementWear.currentDisplayMode);
			print("Info - ImplementWear: Settings successfully loaded");
		else
			print("Warning - ImplementWear: Settings file version did not match (file has " .. (xmlVersion < ImplementWear.VERSION and "older" or "newer") .. " version). Overwriting with current version's default settings");
			ImplementWear.saveSettings();
		end
	else
		print("Info - ImplementWear: Settings file could not be found. Creating new settings file '" .. settingsFilePath .. "'");
		ImplementWear.saveSettings();
	end
end

--[[
	Saves the current settings to the settings file.
]]
function ImplementWear.saveSettings()
	print("Info - ImplementWear: Saving settings...");
	local settingsFilePath = ImplementWear.getSettingsFilePath();
    if settingsFilePath == nil then
		print("Error - ImplementWear: Could not get a valid file path")
		return;
	end

	local file = createXMLFile("ImplementWearSettingsFile", settingsFilePath, "ImplementWear")
	setXMLInt(file, "ImplementWear#VERSION", ImplementWear.VERSION);
	setXMLFloat(file, "ImplementWear.color.normal#R", ImplementWear.color.normal[1]);
	setXMLFloat(file, "ImplementWear.color.normal#G", ImplementWear.color.normal[2]);
	setXMLFloat(file, "ImplementWear.color.normal#B", ImplementWear.color.normal[3]);
	setXMLFloat(file, "ImplementWear.color.normal#A", ImplementWear.color.normal[4]);
	setXMLFloat(file, "ImplementWear.color.warning#R", ImplementWear.color.warning[1]);
	setXMLFloat(file, "ImplementWear.color.warning#G", ImplementWear.color.warning[2]);
	setXMLFloat(file, "ImplementWear.color.warning#B", ImplementWear.color.warning[3]);
	setXMLFloat(file, "ImplementWear.color.warning#A", ImplementWear.color.warning[4]);
	setXMLFloat(file, "ImplementWear.color.urgent#R", ImplementWear.color.urgent[1]);
	setXMLFloat(file, "ImplementWear.color.urgent#G", ImplementWear.color.urgent[2]);
	setXMLFloat(file, "ImplementWear.color.urgent#B", ImplementWear.color.urgent[3]);
	setXMLFloat(file, "ImplementWear.color.urgent#A", ImplementWear.color.urgent[4]);

	setXMLFloat(file, "ImplementWear.position#x", ImplementWear.position[1]);
	setXMLFloat(file, "ImplementWear.position#y", ImplementWear.position[2]);
	setXMLBool(file, "ImplementWear.name#includeBrand", ImplementWear.includeBrand);
	setXMLInt(file, "ImplementWear.name#maxNameLength", ImplementWear.maxNameLength);
	setXMLInt(file, "ImplementWear.name#childIndent", ImplementWear.childIndent);
	setXMLFloat(file, "ImplementWear.font#size", ImplementWear.font.size);
	setXMLFloat(file, "ImplementWear.font#line", ImplementWear.font.line);

	setXMLInt(file, "ImplementWear.limits#warning", ImplementWear.limits.warning);
	setXMLInt(file, "ImplementWear.limits#urgent", ImplementWear.limits.urgent);
	setXMLInt(file, "ImplementWear.displayMode#currentDisplayMode", ImplementWear.currentDisplayMode);

	saveXMLFile(file);
	print("Info - ImplementWear: Settings successfully saved");
end

--[[
	Returns the file path to the settings file, which is located in the modSettings folder.
	ImplementWear.settingsFileName has to have a valid value (not nil and at least 1 character long).
	Returns nil if settingsFileName has an invalid value.
]]
function ImplementWear.getSettingsFilePath()
	if ImplementWear.settingsFileName == nil or string.len(ImplementWear.settingsFileName) <= 0 then
		print("Error - ImplementWear: settingsFileName is invalid");
		return
	end
	local path = getUserProfileAppPath() .. "modSettings/";
	createFolder(path);
	local path = path .. ImplementWear.settingsFileName;
	return path;
end

function ImplementWear:mouseEvent(posX, posY, isDown, isUp, button)
end

function ImplementWear:keyEvent(unicode, sym, modifier, isDown)
end

function ImplementWear:registerActionEvents()
	local r2, eventName1 = g_inputBinding:registerActionEvent('IW_debug_print_stats', self, ImplementWear.debugPrintCurrentVehicle, false, true, false, true);
	g_inputBinding.events[eventName1].displayIsVisible = false;
	local r2, eventName2 = g_inputBinding:registerActionEvent('IW_switch_display_mode', self, ImplementWear.switchDisplayMode, false, true, false, true);
	g_inputBinding.events[eventName2].displayIsVisible = false;
	local r2, eventName3 = g_inputBinding:registerActionEvent('IW_reload_settings', self, ImplementWear.loadSettings, false, true, false, true);
	g_inputBinding.events[eventName3].displayIsVisible = false;
end

--[[
	Called every game tick
]]
function ImplementWear:update(dt)
end

--[[ 
	Called for every frame.
	Retrieves the name, wear, and condition of the currently controlled vehicle and its connected implement(s), 
	then renders the info (depending on the currentDisplayMode) on the screen
]]
function ImplementWear:draw(dt)
	if not g_currentMission.isLoaded or g_currentMission.player == nil then
		return;
	end

	if (g_currentMission.controlledVehicle ~= nil and ImplementWear.currentDisplayMode ~= ImplementWear.displayModes.DISPLAY_OFF) then
		local vehicleInfo = ImplementWear.getVehicleInfo(g_currentMission.controlledVehicle, 0);
		ImplementWear.renderVehicleInfo(vehicleInfo, 0, 0);
	end

	-- Debug:
	-- if (g_currentMission.controlledVehicle ~= nil and g_currentMission.controlledVehicle ~= lastVehicle) then
	-- 	DebugUtil.printTableRecursively(ImplementWear.getVehicleInfo(g_currentMission.controlledVehicle, 0), "-", 0, 5)
	-- 	local lastVehicle = g_currentMission.controlledVehicle;
	-- end

	--respect settings for other mods
	setTextAlignment(0);
	setTextColor(1, 1, 1, 1);
	setTextBold(false);
	--respect settings for other mods
end

--[[
	Renders the given vehicleInfo on the screen, and returns the amount of lines rendered.
]]
function ImplementWear.renderVehicleInfo(vehicleInfo, vIndex, hIndex) --TODO:
	if vehicleInfo == nil or vIndex == nil or hIndex == nil then
		print("ImplementWear.renderVehicleInfo: One or more parameters were nil!");
		return;
	end
	local vehicleLine = ImplementWear.dataToString(vehicleInfo.name, vehicleInfo.condition, vehicleInfo.damage, vehicleInfo.paint, hIndex * ImplementWear.childIndent);
	local y = ImplementWear.position[2] - (vIndex * ImplementWear.font.size * ImplementWear.font.line);

	-- Make the main/root vehicle bold
	if vIndex == 0 and hIndex == 0 then
		setTextBold(true);
	end
	-- Set the text colour depending on the damage 
	if vehicleInfo.damage >= ImplementWear.limits.warning then
		setTextColor(unpack(ImplementWear.color.normal));
	elseif vehicleInfo.damage >= ImplementWear.limits.urgent then
		setTextColor(unpack(ImplementWear.color.warning));
	else
		setTextColor(unpack(ImplementWear.color.urgent));
	end
	renderText(ImplementWear.position[1], y, ImplementWear.font.size, vehicleLine);
	setTextBold(false);
	local nRenderedLines = 1; -- Keeps track of the number of printed lines by this vehicle and all of its (sub) implements

	for i, implement in pairs(vehicleInfo.implements) do
		nRenderedLines = nRenderedLines + ImplementWear.renderVehicleInfo(implement, vIndex + nRenderedLines, hIndex + 1);
	end
	return nRenderedLines;
end

--[[
	Returns a string containing the given data, formatted depending on the currentDisplayMode:
	 - 0: method should not have been called. If called anyway, data is formatted like currentDisplayMode=1
	 - 1: '<name> and wear'
	 - 2: 'name, wear and condition'
	'indent' indicates the number of empty spaces ' ' prepended to the string
]]
function ImplementWear.dataToString(name, condition, damage, paint, indent)
	-- Check whether all parameters have a valid value, and assign one otherwise
	if name == nil then
		name = "???";
	elseif ImplementWear.currentDisplayMode ~= ImplementWear.displayModes.DISPLAY_FULL_NAME and ImplementWear.currentDisplayMode ~= ImplementWear.displayModes.DISPLAY_PAINT_FULL_NAME and string.len(name) > ImplementWear.maxNameLength then
		name = string.sub(name, 0, ImplementWear.maxNameLength-3) .. "...";
	end
	if condition == nil then
		condition = -1;
	end
	if damage == nil then
		damage = -1;
	end
	if paint == nil then
		paint = -1;
	end
	if indent == nil then
		indent = 0;
	end

	-- Append data to the data string depending on the currentDisplayMode
	local line = string.rep(" ", indent);
	local t;
	t = t or {
		[ImplementWear.displayModes.DISPLAY_OFF] = function () return ("") end,
		[ImplementWear.displayModes.DISPLAY_NORMAL] = function () return (name .. " : " .. string.format("%.0f", condition) .. "%") end,
		[ImplementWear.displayModes.DISPLAY_DAMAGE] = function () return (name .. " : " .. string.format("%.0f", condition) .. "%" .. "|" .. string.format("%.0f", damage) .. "%") end,
		[ImplementWear.displayModes.DISPLAY_FULL_NAME] = function () return (name .. " : " .. string.format("%.0f", condition) .. "%" .. "|" .. string.format("%.0f", damage) .. "%") end,
		[ImplementWear.displayModes.DISPLAY_PAINT] = function () return (name .. " : " .. string.format("%.0f", condition) .. "%" .. "|" .. string.format("%.0f", damage) .. "%" .. "|" .. string.format("%.0f", paint) .. "%") end,
		[ImplementWear.displayModes.DISPLAY_PAINT_FULL_NAME] = function () return (name .. " : " .. string.format("%.0f", condition) .. "%" .. "|" .. string.format("%.0f", damage) .. "%" .. "|" .. string.format("%.0f", paint) .. "%") end
	}
	line = line .. t[ImplementWear.currentDisplayMode]();
	return line;
end

--[[
	Returns the 'name' and the 'condition' of the given vehicle, and an array containing that same info of attached 'implements'
]]
function ImplementWear.getVehicleInfo(vehicle, depth)
	if vehicle == nil then
		return
	end

	-- print("Info - ImplementWear: getVehicleInfo called - level " .. depth .. " ---"); -- Debug

	local name, condition, damage, paint;
	name = vehicle:getName();
	-- If the settings are set to include the vehicle's brand, retrieve it from the vehicle XML
	if ImplementWear.includeBrand then
		local storeItem = g_storeManager:getItemByXMLFilename(vehicle.configFileName);
		if storeItem ~= nil then
			local brand = g_brandManager:getBrandByIndex(storeItem.brandIndex);
			if brand ~= nil then
				name = brand.title .. " " .. name;
			end
		end
	end
	
	-- condition = (vehicle.getVehicleDamage ~= nil and (100 - (vehicle:getVehicleDamage() * 100)) or -1);
	condition = (vehicle.getDamageAmount ~= nil and (100 - (vehicle:getDamageAmount() * 100)) or -1);
	damage = (vehicle.getVehicleDamage ~= nil and (100 - (vehicle:getVehicleDamage() * 100)) or -1);
	paint = (vehicle.getWearTotalAmount ~= nil and (100 - (vehicle:getWearTotalAmount() * 100)) or -1);
	
	-- Recursively get the info about the vehicle's implements
	local implements = {};
	if vehicle.getAttachedImplements ~= nil then
		for i, implement in pairs(vehicle:getAttachedImplements()) do
			local implementInfo = ImplementWear.getVehicleInfo(implement.object, depth + 1);
			-- implementInfo.name = i .. ": " .. implementInfo.name;
			implements[i] = implementInfo;
		end
	end

	return {
		name = name,
		condition = condition, 
		damage = damage,
		paint = paint,
		implements = implements
	}
end



--[[
	Prints the currently controlled vehicle's info
]]
function ImplementWear.debugPrintCurrentVehicle() --TODO: remove commented out line
	if (g_currentMission.controlledVehicle ~= nil) then
		DebugUtil.printTableRecursively(ImplementWear.getVehicleInfo(g_currentMission.controlledVehicle, 0), "-", 0, 5)
		--DebugUtil.printTableRecursively(g_currentMission.controlledVehicle, "-", 0, 1)
	else 
		print("Error - ImplementWear: Vehicle is nil");
	end
end

--[[
	Iterates to the next view mode
]]
function ImplementWear.switchDisplayMode()
	if ImplementWear.nDisplayModes == nil then
		print("Error - ImplementWear: No maxDisplayMode is set");
	end
	if ImplementWear.defaultDisplayMode == nil then
		ImplementWear.defaultDisplayMode = 0;
	end
	if ImplementWear.currentDisplayMode == nil then
		ImplementWear.currentDisplayMode = ImplementWear.defaultDisplayMode;
	end
	ImplementWear.currentDisplayMode = (ImplementWear.currentDisplayMode + 1) % ImplementWear.nDisplayModes;
end



if g_client ~= nil then
	-- client side mod only
	addModEventListener(ImplementWear);
	FSBaseMission.registerActionEvents = Utils.appendedFunction(FSBaseMission.registerActionEvents, ImplementWear.registerActionEvents);
end
